# ![Officine Robotiche][Logo] - or_bus_c.X [![Build Status](https://travis-ci.org/officinerobotiche/or_bus_c.X.svg?branch=develop)](https://travis-ci.org/officinerobotiche/or_bus_c.X) [![Stories in Ready](https://badge.waffle.io/officinerobotiche/uNAV.X.png?label=ready&title=Ready)](http://waffle.io/officinerobotiche/uNAV.X)

[![Join the chat at https://gitter.im/officinerobotiche/uNAV.X](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/officinerobotiche/uNAV.X?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
This is a project in development by [Officine Robotiche] to control motors.

Library to communicate with OR boards

## Throughput Graph
[![Throughput Graph](https://graphs.waffle.io/officinerobotiche/uNAV.X/throughput.svg)](https://waffle.io/officinerobotiche/uNAV.X/metrics/throughput)


Developer [*Raffaello Bonghi*](http://rnext.it)

[wiki]:http://wiki.officinerobotiche.it/
[Officine Robotiche]:http://www.officinerobotiche.it/
[Logo]:http://2014.officinerobotiche.it/wp-content/uploads/sites/4/2014/09/ORlogoSimpleSmall.png
