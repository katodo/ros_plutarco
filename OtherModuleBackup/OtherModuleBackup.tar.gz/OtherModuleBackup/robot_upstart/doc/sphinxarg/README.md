sphinxarg
=========

From: https://github.com/ribozz/sphinx-argparse
